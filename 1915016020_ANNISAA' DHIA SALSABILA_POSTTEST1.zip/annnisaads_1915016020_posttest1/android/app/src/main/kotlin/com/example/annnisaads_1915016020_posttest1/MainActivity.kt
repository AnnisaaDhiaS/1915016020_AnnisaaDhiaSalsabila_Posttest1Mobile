package com.example.annnisaads_1915016020_posttest1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
